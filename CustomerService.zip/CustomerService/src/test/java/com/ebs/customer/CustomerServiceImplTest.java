//package com.ebs.customer;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//
//import com.ebs.customer.dto.CustomerDto;
//import com.ebs.customer.entity.Customer;
//import com.ebs.customer.exception.*;
//import com.ebs.customer.repository.CustomerRepository;
//import com.ebs.customer.serviceimpl.CustomerServiceImpl;
//
//public class CustomerServiceImplTest {
//   
//    private CustomerRepository customerRepositoryMock;
//    private CustomerServiceImpl customerService;
//
//    @BeforeEach
//    public void setup() {
//        customerRepositoryMock = mock(CustomerRepository.class);
//        customerService = new CustomerServiceImpl();
//    }
//
//    @Test
//    public void testRegisterCustomer_Success() {
//        Customer customer = createMockCustomer();
//        when(customerRepositoryMock.findByEmailId(customer.getEmailId())).thenReturn(null);
//        when(customerRepositoryMock.save(customer)).thenReturn(customer);
//
//        Customer registeredCustomer = customerService.registerCustomer(customer);
//
//        assertNotNull(registeredCustomer);
//        assertEquals(customer.getEmailId(), registeredCustomer.getEmailId());
//    }
//
//    @Test
//    public void testRegisterCustomer_AlreadyExist() {
//        Customer customer = createMockCustomer();
//        when(customerRepositoryMock.findByEmailId(customer.getEmailId())).thenReturn(customer);
//
//        assertThrows(CustomerAlreadyExistException.class, () -> customerService.registerCustomer(customer));
//    }
//
//    @Test
//    public void testRegisterCustomer_InvalidData() {
//        Customer customer = createMockCustomer();
//        customer.setFirstName("");
//
//        assertThrows(InvalidDataException.class, () -> customerService.registerCustomer(customer));
//    }
//
//    @Test
//    public void testRegisterCustomer_InvalidEmailId() {
//        Customer customer = createMockCustomer();
//        customer.setEmailId("invalid_email");
//
//        assertThrows(InvalidEmailIdException.class, () -> customerService.registerCustomer(customer));
//    }
//
//    @Test
//    public void testRegisterCustomer_InvalidName() {
//        Customer customer = createMockCustomer();
//        customer.setFirstName("123");
//
//        assertThrows(InvalidNameException.class, () -> customerService.registerCustomer(customer));
//    }
//
//    @Test
//    public void testRegisterCustomer_InvalidAadharNumber() {
//        Customer customer = createMockCustomer();
//        customer.setAdharNumber("123");
//
//        assertThrows(InvalidAadharNumber.class, () -> customerService.registerCustomer(customer));
//    }
//
//    @Test
//    public void testRegisterCustomer_InvalidGender() {
//        Customer customer = createMockCustomer();
//        customer.setGender("invalid_gender");
//
//        assertThrows(InvalidGenderException.class, () -> customerService.registerCustomer(customer));
//    }
//
//    @Test
//    public void testRegisterCustomer_InvalidPassword() {
//        Customer customer = createMockCustomer();
//        customer.setPassword("weakpassword");
//
//        assertThrows(InvalidPasswordException.class, () -> customerService.registerCustomer(customer));
//    }
//
//    @Test
//    public void testRegisterCustomer_InvalidMobileNumber() {
//        Customer customer = createMockCustomer();
//        customer.setMobileNumber("123");
//
//        assertThrows(InvalidMobileNumberException.class, () -> customerService.registerCustomer(customer));
//    }
//
//    @Test
//    public void testLoginCustomer_Success() {
//        Customer customer = createMockCustomer();
//        when(customerRepositoryMock.findByEmailId(customer.getEmailId())).thenReturn(customer);
//
//        String result = customerService.loginCustomer(customer.getEmailId(), customer.getPassword());
//
//        assertEquals("Login Successfully", result);
//    }
//
//    @Test
//    public void testLoginCustomer_NotRegistered() {
//        when(customerRepositoryMock.findByEmailId(any(String.class))).thenReturn(null);
//
//        assertThrows(UserIsNotRegisterException.class, () -> customerService.loginCustomer("nonexistent@example.com", "password"));
//    }
//
//    @Test
//    public void testLoginCustomer_InvalidPassword() {
//        Customer customer = createMockCustomer();
//        when(customerRepositoryMock.findByEmailId(customer.getEmailId())).thenReturn(customer);
//
//        assertThrows(InvalidEmailPasswordException.class, () -> customerService.loginCustomer(customer.getEmailId(), "incorrect_password"));
//    }
//
//    @Test
//    public void testEditCustomer_Success() {
//        Long customerId = 1L;
//        Customer customer = createMockCustomer();
//        Optional<Customer> optionalCustomer = Optional.of(customer);
//        when(customerRepositoryMock.findById(customerId)).thenReturn(optionalCustomer);
//
//        String result = customerService.editCustomer(customerId, customer);
//
//        assertEquals("Customer details updated successfully", result);
//        verify(customerRepositoryMock).save(customer);
//    }
//
//    @Test
//    public void testEditCustomer_CustomerNotFound() {
//        Long customerId = 1L;
//        when(customerRepositoryMock.findById(customerId)).thenReturn(Optional.empty());
//
//        assertThrows(CustomerIdNotFound.class, () -> customerService.editCustomer(customerId, createMockCustomer()));
//    }
//
//    @Test
//    public void testForgotPassword_Success() {
//        Customer customer = createMockCustomer();
//        CustomerDto customerDto = new CustomerDto();
//        customerDto.setEmailId(customer.getEmailId());
//        customerDto.setPassword("new_password");
//        customerDto.setConfirmPassword("new_password");
//
//        when(customerRepositoryMock.findByEmailId(customerDto.getEmailId())).thenReturn(customer);
//
//        String result = customerService.forgotPassword(customerDto);
//
//        assertEquals("Password Reset Succesfully", result);
//        assertEquals(customerDto.getPassword(), customer.getPassword());
//        verify(customerRepositoryMock).save(customer);
//    }
//
//    @Test
//    public void testForgotPassword_UserNotRegistered() {
//        CustomerDto customerDto = new CustomerDto();
//        customerDto.setEmailId("nonexistent@example.com");
//        customerDto.setPassword("new_password");
//        customerDto.setConfirmPassword("new_password");
//
//        when(customerRepositoryMock.findByEmailId(any(String.class))).thenReturn(null);
//
//        assertThrows(UserIsNotRegisterException.class, () -> customerService.forgotPassword(customerDto));
//    }
//
//    @Test
//    public void testForgotPassword_InvalidPassword() {
//        Customer customer = createMockCustomer();
//        CustomerDto customerDto = new CustomerDto();
//        customerDto.setEmailId(customer.getEmailId());
//        customerDto.setPassword("weak");
//
//        when(customerRepositoryMock.findByEmailId(customerDto.getEmailId())).thenReturn(customer);
//
//        assertThrows(InvalidPasswordException.class, () -> customerService.forgotPassword(customerDto));
//    }
//
//    @Test
//    public void testForgotPassword_PasswordMismatch() {
//        Customer customer = createMockCustomer();
//        CustomerDto customerDto = new CustomerDto();
//        customerDto.setEmailId(customer.getEmailId());
//        customerDto.setPassword("new_password");
//        customerDto.setConfirmPassword("different_password");
//
//        when(customerRepositoryMock.findByEmailId(customerDto.getEmailId())).thenReturn(customer);
//
//        assertThrows(PasswordMismatchException.class, () -> customerService.forgotPassword(customerDto));
//    }
//
//    @Test
//    public void testDeleteCustomer_Success() {
//        Long customerId = 1L;
//        when(customerRepositoryMock.existsById(customerId)).thenReturn(true);
//
//        String result = customerService.deleteCustomer(customerId);
//
//        assertEquals("Customer deleted successfully", result);
//        verify(customerRepositoryMock).deleteById(customerId);
//    }
//
//    @Test
//    public void testDeleteCustomer_NotFound() {
//        Long customerId = 1L;
//        when(customerRepositoryMock.existsById(customerId)).thenReturn(false);
//
//        String result = customerService.deleteCustomer(customerId);
//
//        assertEquals("Customer with ID " + customerId + " not found", result);
//    }
//
//    @Test
//    public void testGetAllCustomer_Success() {
//        List<Customer> customers = new ArrayList<>();
//        customers.add(createMockCustomer());
//        when(customerRepositoryMock.findAll()).thenReturn(customers);
//
//        List<Customer> result = customerService.getAllCustomer();
//
//        assertNotNull(result);
//        assertEquals(1, result.size());
//    }
//
//    @Test
//    public void testSearchCustomerByCustomerId_Success() {
//        Long customerId = 1L;
//        Customer customer = createMockCustomer();
//        when(customerRepositoryMock.existsById(customerId)).thenReturn(true);
//        when(customerRepositoryMock.findById(customerId)).thenReturn(Optional.of(customer));
//
//        CustomerDto result = customerService.searchCustomerByCustomerId(customerId);
//
//        assertNotNull(result);
//        assertEquals(customer.getFirstName(), result.getFirstName());
//        assertEquals(customer.getLastName(), result.getLastName());
//    }
//
//    @Test
//    public void testSearchCustomerByCustomerId_NotFound() {
//        Long customerId = 1L;
//        when(customerRepositoryMock.existsById(customerId)).thenReturn(false);
//
//        assertThrows(CustomerIdNotFound.class, () -> customerService.searchCustomerByCustomerId(customerId));
//    }
//
//    private Customer createMockCustomer() {
//        Customer customer = new Customer();
//        customer.setCustomerId(1L);
//        customer.setFirstName("John");
//        customer.setLastName("Doe");
//        customer.setEmailId("john.doe@example.com");
//        customer.setAdharNumber("123456789012");
//        customer.setGender("M");
//        customer.setPassword("Password@123");
//        customer.setMobileNumber("9876543210");
//        return customer;
//    }
//}
