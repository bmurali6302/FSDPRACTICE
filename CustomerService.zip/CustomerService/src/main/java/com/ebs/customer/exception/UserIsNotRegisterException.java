package com.ebs.customer.exception;

public class UserIsNotRegisterException extends RuntimeException {
	String message;

	public UserIsNotRegisterException() {
		super();
	}

	public UserIsNotRegisterException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	

}
