package com.ebs.customer.exception;

public class InvalidEmailIdException extends RuntimeException{
	String message;

	public InvalidEmailIdException() {
		super();
	}

	public InvalidEmailIdException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
