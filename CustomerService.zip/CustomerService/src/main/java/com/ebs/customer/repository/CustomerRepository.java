package com.ebs.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ebs.customer.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer,Long>{
	Customer findByEmailId(String email);
	//Customer updateCustomer(Long customerId,Customer customer);
	//BillDto getBillByCustomerId(Long id);

}
