package com.ebs.customer.globalhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.ebs.customer.exception.CustomerAlreadyExistException;
import com.ebs.customer.exception.InvalidEmailIdException;
import com.ebs.customer.exception.InvalidNameException;
import com.ebs.customer.exception.InvalidMobileNumberException;
import com.ebs.customer.exception.CustomerIdNotFound;
import com.ebs.customer.exception.InvalidAadharNumber;
import com.ebs.customer.exception.InvalidEmailPasswordException;
import com.ebs.customer.exception.InvalidGenderException;
import com.ebs.customer.exception.PasswordMismatchException;
import com.ebs.customer.exception.CustomerDetailsUpdated;
import com.ebs.customer.exception.InvalidPasswordException;
import com.ebs.customer.exception.InvalidDataException;
import com.ebs.customer.exception.UserIsNotRegisterException;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	ApiError error = new ApiError();
	
	@ExceptionHandler({
		CustomerAlreadyExistException.class,
		InvalidEmailIdException.class,
		InvalidNameException.class,
		InvalidPasswordException.class,
		InvalidMobileNumberException.class,
		InvalidEmailPasswordException.class,
		InvalidAadharNumber.class,
		CustomerIdNotFound.class,
		InvalidGenderException.class,
		InvalidDataException.class,
		CustomerDetailsUpdated.class,
		UserIsNotRegisterException.class
	})
	public ResponseEntity<Object>ExistException(Exception ex){
  	error.setStatus(HttpStatus.BAD_REQUEST);
  	error.setMessage(ex.getMessage());
  	error.setTimestamp(LocalDateTime.now());
  	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
  }
	
//	@ExceptionHandler(CustomerAlreadyExistException.class)
//	 public ResponseEntity<Object> CustomerAlreadyExistException(Exception ex){
//   	error.setStatus(HttpStatus.BAD_REQUEST);
//   	error.setMessage("User is already registered");
//   	error.setTimestamp(LocalDateTime.now());
//   	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
//   }
//	@ExceptionHandler(InvalidEmailIdException.class)
//	 public ResponseEntity<Object> InvalidEmailIdException(Exception ex){
//   	error.setStatus(HttpStatus.BAD_REQUEST);
//   	error.setMessage("Invalid emailId format");
//   	error.setTimestamp(LocalDateTime.now());
//   	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
//   }
//	
//	@ExceptionHandler(InvalidNameException.class)
//	 public ResponseEntity<Object> InvalidNameException(Exception ex){
//  	error.setStatus(HttpStatus.BAD_REQUEST);
//  	error.setMessage("Invalid name format");
//  	error.setTimestamp(LocalDateTime.now());
//  	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
//  }
//	
//	@ExceptionHandler(com.ebs.customer.exception.InvalidPasswordException.class)
//	 public ResponseEntity<Object> InvalidPasswordException(Exception ex){
// 	error.setStatus(HttpStatus.BAD_REQUEST);
// 	error.setMessage("Invalid password format");
// 	error.setTimestamp(LocalDateTime.now());
// 	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
// }
//	@ExceptionHandler(InvalidMobileNumberException.class)
//	 public ResponseEntity<Object> InvalidMobileNumberException(Exception ex){
//  	error.setStatus(HttpStatus.BAD_REQUEST);
//  	error.setMessage("Invalid mobile number");
//  	error.setTimestamp(LocalDateTime.now());
//  	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
//  }
//	@ExceptionHandler(InvalidEmailPasswordException.class)
//	 public ResponseEntity<Object> InvalidEmailPasswordException(Exception ex){
//  	error.setStatus(HttpStatus.BAD_REQUEST);
//  	error.setMessage("Invalid password please provide valid");
//  	error.setTimestamp(LocalDateTime.now());
//  	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
//  }
//	@ExceptionHandler(InvalidAadharNumber.class)
//	 public ResponseEntity<Object> InvalidAadharNumber(Exception ex){
//  	error.setStatus(HttpStatus.BAD_REQUEST);
//  	error.setMessage("Invalid aadhar number");
//  	error.setTimestamp(LocalDateTime.now());
//  	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
//  }
//
//	@ExceptionHandler(CustomerIdNotFound.class)
//	 public ResponseEntity<Object> CustomerIdNotFound(Exception ex){
// 	error.setStatus(HttpStatus.BAD_REQUEST);
// 	error.setMessage("Customer id not found");
// 	error.setTimestamp(LocalDateTime.now());
// 	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
// }
//
//	@ExceptionHandler(InvalidGenderException.class)
//	 public ResponseEntity<Object> InvalidGenderException(InvalidGenderException ex){
// 	error.setStatus(HttpStatus.BAD_REQUEST);
// 	error.setMessage("Invalid gender format");
// 	error.setTimestamp(LocalDateTime.now());
// 	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
// }
//
//	@ExceptionHandler(PasswordMismatchException.class)
//	 public ResponseEntity<Object> PasswordMismatchException(Exception ex){
// 	error.setStatus(HttpStatus.BAD_REQUEST);
// 	error.setMessage("Password mismatch");
// 	error.setTimestamp(LocalDateTime.now());
// 	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
// }
//	@ExceptionHandler(InvalidDataException.class)
//	 public ResponseEntity<Object> InvalidDataException(Exception ex){
//	error.setStatus(HttpStatus.BAD_REQUEST);
//	error.setMessage("Please provide data");
//	error.setTimestamp(LocalDateTime.now());
//	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
//}
//	
//	@ExceptionHandler(CustomerDetailsUpdated.class)
//	 public ResponseEntity<Object> CustomerDetailsUpdated(Exception ex){
//	error.setMessage("User is already registered");
//	return new ResponseEntity<>(error, HttpStatus.valueOf(200));
//}
//	
//	@ExceptionHandler(UserIsNotRegisterException.class)
//	 public ResponseEntity<Object> UserIsNotRegisterException(Exception ex){
//	error.setStatus(HttpStatus.BAD_REQUEST);
//	error.setMessage("User is not register");
//	error.setTimestamp(LocalDateTime.now());
//	return new ResponseEntity<>(error, HttpStatus.valueOf(400));
//}


//	@ExceptionHandler(CustomerAlreadyExistException.class)
//	public ResponseEntity<String> UserAlreadyExistException(CustomerAlreadyExistException ex) {
//		System.out.println(ex);
//		return new ResponseEntity<String>("User is already registered", HttpStatus.BAD_REQUEST);
//
//	}
//	@ExceptionHandler(InvalidEmailIdException.class)
//	public ResponseEntity<String> InvalidEmailIdException(InvalidEmailIdException ex)
//	{
//		System.out.println(ex);
//		return new ResponseEntity<String>("Invalid Email Format",HttpStatus.OK);
//		
//	}
/*	@ExceptionHandler(InvalidAddressException.class)
	public ResponseEntity<String> InvalidAddressException(InvalidAddressException ex)
	{
		System.out.println(ex);
		return new ResponseEntity<String>("please provide address",HttpStatus.OK);
		
	}
	@ExceptionHandler(InvalidNameException.class)
	public ResponseEntity<String> InvalidNameException(InvalidNameException ex)
	{
		System.out.println(ex);
		return new ResponseEntity<String>("Invalid name format",HttpStatus.OK);
	}
	@ExceptionHandler(InvalidMobileNumberException.class)
	public ResponseEntity<String> InvalidMobileNumberException(InvalidMobileNumberException ex){
		System.out.println(ex);
		return new ResponseEntity<String>("Invalid mobile number",HttpStatus.OK);
	}
	@ExceptionHandler(CustomerIdNotFound.class)
	public ResponseEntity<String> CustomerIdNotFound(CustomerIdNotFound ex){
		System.out.println(ex);
		return new ResponseEntity<String>("Customer id not found",HttpStatus.OK);
	}
	@ExceptionHandler(InvalidEmailPasswordException.class)
	public ResponseEntity<String> InvalidEmailPasswordException(InvalidEmailPasswordException ex){
		System.out.println(ex);
		return new ResponseEntity<String>("InvalidEmailPasswordException",HttpStatus.OK);
	}
	@ExceptionHandler(PasswordMismatchException.class)
	public ResponseEntity<String> PasswordMismatchException(PasswordMismatchException ex){
		System.out.println(ex);
		return new ResponseEntity<String> ("PasswordMismatchException",HttpStatus.OK);
	}
	
	@ExceptionHandler(CustomerDetailsUpdated.class)
	public ResponseEntity<String> CustomerDetailsUpdated(CustomerDetailsUpdated ex){
		System.out.println(ex);
		return new ResponseEntity<String> ("CustomerDetailsUpdated",HttpStatus.OK);
	}
	@ExceptionHandler(InvalidAadharNumber.class)
	public ResponseEntity<String> InvalidAadharNumber(InvalidAadharNumber ex){
		System.out.println(ex);
		return new ResponseEntity<String>("InvalidAadharNumber",HttpStatus.OK);
	}
	@ExceptionHandler(InvalidGenderException.class)
	public ResponseEntity<String> InvalidGenderException(InvalidGenderException ex){
		System.out.println(ex);
		return new ResponseEntity<String> ("InvalidGenderException",HttpStatus.OK);
	}
	
	@ExceptionHandler(InvalidPasswordException.class)
	public ResponseEntity<String> InvalidPasswordException(InvalidPasswordException ex){
		System.out.println(ex);
		return new ResponseEntity<String> ("Invalid Password Exception",HttpStatus.OK);
	}
	*/
		
	

//	@ExceptionHandler({
//		InvalidEmailIdException.class,
//		InvalidNameException.class,
//		InvalidMobileNumberException.class,
//		InvalidEmailPasswordException.class,
//		InvalidAadharNumber.class,
//		InvalidGenderException.class,
//		InvalidGenderException.class
//		}
//	)
//	 public ResponseEntity<Object> handleInvalidException(Exception ex){
//    	ApiError error = new ApiError();
//    	error.setStatus(HttpStatus.UNAUTHORIZED);
//    	error.setMessage(error.getMessage());
//    	error.setTimestamp(LocalDateTime.now());
//    	return new ResponseEntity<>(error, HttpStatus.valueOf(401));
//    }
	

}
