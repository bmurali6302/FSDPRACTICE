package com.ebs.customer.exception;

public class InvalidNameException extends RuntimeException {
	String message;

	public InvalidNameException() {
		super();
	}

	public InvalidNameException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	

}
