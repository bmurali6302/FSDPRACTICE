package com.ebs.customer.serviceimpl;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.ebs.customer.dto.CustomerDto;
import com.ebs.customer.entity.Customer;
import com.ebs.customer.exception.CustomerAlreadyExistException;
import com.ebs.customer.exception.CustomerIdNotFound;
import com.ebs.customer.exception.InvalidAadharNumber;
import com.ebs.customer.exception.InvalidDataException;
import com.ebs.customer.exception.InvalidEmailIdException;
import com.ebs.customer.exception.InvalidEmailPasswordException;
import com.ebs.customer.exception.InvalidGenderException;
import com.ebs.customer.exception.InvalidMobileNumberException;
import com.ebs.customer.exception.InvalidNameException;
import com.ebs.customer.exception.InvalidPasswordException;
import com.ebs.customer.exception.PasswordMismatchException;
import com.ebs.customer.exception.UserIsNotRegisterException;
import com.ebs.customer.repository.CustomerRepository;
import com.ebs.customer.service.CustomerService;
import com.ebs.customer.vo.Bill;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepository customerRepository;
	@Autowired
	ModelMapper modelmapper;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Customer registerCustomer(Customer customer){
		Customer isExist = customerRepository.findByEmailId(customer.getEmailId());
		if (isExist != null) {
			throw new CustomerAlreadyExistException("Customer is already exist");
		}
		else if(customer.getAddress().isEmpty()||customer.getEmailId().isEmpty()||customer.getFirstName().isEmpty()||
				customer.getLastName().isEmpty()||customer.getAdharNumber().isEmpty()||customer.getGender().isEmpty()||
				customer.getPassword().isEmpty()||customer.getMobileNumber().isEmpty()) {
			throw new InvalidDataException("Please provide data");
		}
		else{
			
		if  (!customer.getEmailId().matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
				throw new InvalidEmailIdException("please enter valid email");
			}
			if (!customer.getFirstName().matches("^[a-zA-Z]+(\s[a-zA-Z]+)?$"))
			     {
				throw new InvalidNameException("please enter valid name");
			}
			if (!customer.getLastName().matches("^[a-zA-Z]+(\s[a-zA-Z]+)?$"))
		     {
			throw new InvalidNameException("please enter valid lastName");
		    }
			if(!customer.getAdharNumber().matches("^\\d{12}$")) {
				throw new InvalidAadharNumber("Invalid Aadhar Number : "+customer.getAdharNumber());
			}
			if(!customer.getGender().matches("^[MFmf]$")) {
				throw new InvalidGenderException("Invalid_Gender");
			}
			if (!customer.getPassword().matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$")) {
				throw new InvalidPasswordException("Invalid_password");
			}
			if (!String.valueOf(customer.getMobileNumber()).matches("^[6-9]\\d{9}$")) {
				throw new InvalidMobileNumberException("Invalid mobile number");
			}
			
		}
		
		
		return customerRepository.save(customer);
		 
		
	}
	@Override
	public String loginCustomer(String email, String password) {
		Customer customer=customerRepository.findByEmailId(email);
		if(customer!=null && customer.getPassword().equals(password))
			return "Login Successfully";
		else if(customer==null) {
			throw new UserIsNotRegisterException();
			
		}
		throw new InvalidEmailPasswordException("Invalid_password");
	}
	@Override
	public String editCustomer(Long customerId,Customer customer) {
		Optional<Customer> optionalCustomer = customerRepository.findById(customerId);
		if (optionalCustomer.isPresent()) {
			Customer existingCustomer = optionalCustomer.get();
			existingCustomer.setAdharNumber(customer.getAdharNumber());
			existingCustomer.setFirstName(customer.getFirstName());
			existingCustomer.setLastName(customer.getLastName());
			existingCustomer.setMobileNumber(customer.getMobileNumber());
			existingCustomer.setAddress(customer.getAddress());
			existingCustomer.setEmailId(customer.getEmailId());
			existingCustomer.setGender(customer.getGender());
			customerRepository.save(existingCustomer);
			return "Customer details updated successfully";
		} else {
			throw new CustomerIdNotFound("Customer with ID " + customerId + " not found");
		}
	}
	@Override
	public String forgotPassword(CustomerDto customerDto) {
		Customer customer=customerRepository.findByEmailId(customerDto.getEmailId());
		if(customer==null) {
			throw new UserIsNotRegisterException();
		}else if(!customerDto.getPassword().matches("^[a-zA-Z0-9_@#]{8,14}$")) {
			throw new InvalidPasswordException("Invalid_password");
		}else if(!customerDto.getConfirmPassword().matches(customerDto.getPassword())) {
			throw new PasswordMismatchException("Invalid_Password");
		}
		else {
			customer.setPassword(customerDto.getPassword());
			customerRepository.save(customer);
			return "Password Reset Succesfully";
		}		
	}
	@Override
	public String deleteCustomer(Long customerId) {
		if (customerRepository.existsById(customerId)) {
			customerRepository.deleteById(customerId);
            return "Customer deleted successfully";
        } else {
            return "Customer with ID " + customerId + " not found";
        }
	}
	@Override
	public List<Customer> getAllCustomer() {
		return customerRepository.findAll();
	}
	@Override
	public CustomerDto searchCustomerByCustomerId(Long customerId) {
		if(customerRepository.existsById(customerId)) {
			Customer customer=customerRepository.findById(customerId).get();
			CustomerDto customers=new CustomerDto();
			customers.setCustomerId(customer.getCustomerId());
			customers.setAdharNumber(customer.getAdharNumber());
			customers.setFirstName(customer.getFirstName());
			customers.setLastName(customer.getLastName());	
			customers.setEmailId(customer.getEmailId());
			customers.setAddress(customer.getAddress());
			customers.setGender(customer.getGender());
			customers.setMobileNumber(customer.getMobileNumber());
			return customers;
			}else {
				throw new CustomerIdNotFound("Customer with ID " + customerId + " not found");
			}
	}

	@Override
	public Bill viewAllBillByCustomerId(Long customerId) {
		if(!customerRepository.existsById(customerId)) {
			throw new CustomerIdNotFound("Customer with ID " + customerId + " not found");
		}else {
			
			Bill response=restTemplate.getForObject("http://billing-service/api/bill/"+customerId,Bill.class);
			return response;
		}
	}
}