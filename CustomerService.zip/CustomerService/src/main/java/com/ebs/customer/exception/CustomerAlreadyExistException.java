package com.ebs.customer.exception;

public class CustomerAlreadyExistException extends RuntimeException{
	String message;

	public CustomerAlreadyExistException() {
		super();
	}
	

	public CustomerAlreadyExistException(String message) {
		super();
		this.message = message;
	}


	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "CustomerAlreadyExistException [message=" + message + "]";
	}
	
	
	

}
