package com.ebs.customer.service;
import java.util.List;
import com.ebs.customer.dto.CustomerDto;
import com.ebs.customer.entity.Customer;
import com.ebs.customer.vo.Bill;

public interface CustomerService {
	public Customer registerCustomer(Customer customer);
	public String loginCustomer(String email,String password);
	public String editCustomer(Long customerId,Customer customer);
	public String forgotPassword(CustomerDto customerDto);
    public String deleteCustomer(Long customerId);
    public List<Customer> getAllCustomer();
    public CustomerDto searchCustomerByCustomerId(Long customerId);
    
    
    
    public Bill viewAllBillByCustomerId(Long customerId);
}
