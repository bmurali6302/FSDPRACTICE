package com.ebs.customer.exception;

public class InvalidGenderException extends RuntimeException{
	String message;

	public InvalidGenderException() {
		super();
	}

	public InvalidGenderException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	

}
