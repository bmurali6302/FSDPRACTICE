package com.ebs.customer.vo;

import com.ebs.customer.entity.Customer;

public class ResponseTemplateVO {
	private Customer customer;
	private Bill bill;
	public ResponseTemplateVO() {
		super();
	}
	public ResponseTemplateVO(Customer customer, Bill bill) {
		super();
		this.customer = customer;
		this.bill = bill;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Bill getBill() {
		return bill;
	}
	public void setBill(Bill bill) {
		this.bill = bill;
	}
	

}
