package com.ebs.customer.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class CustomerDto {

	private Long customerId;
	@NotNull(message="Aadhar number is mandatory")
	private String adharNumber;
	@NotEmpty(message="firstName is mandatory")
	private String firstName;
	@NotEmpty(message="lastName is mandatory")
	private String lastName;
	@NotEmpty(message="mobileNumber is mandatory")
	private String mobileNumber;
	@NotEmpty(message="address is mandatory")
	private String address;
	@Email
	@NotEmpty
	@Pattern(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z]+.[a-zA-A]+", message = "enter email in valid format")
	private String emailId;
	@JsonProperty(access = Access.WRITE_ONLY)
	@NotEmpty
	private String password;
	@NotEmpty
	private String gender;
	@JsonProperty(access = Access.WRITE_ONLY)
	private String confirmPassword;

	public CustomerDto() {
		super();
	}

	public CustomerDto(Long customerId, @NotNull(message = "Aadhar number is mandatory") String adharNumber,
			@NotEmpty(message = "firstName is mandatory") String firstName,
			@NotEmpty(message = "lastName is mandatory") String lastName,
			@NotEmpty(message = "mobileNumber is mandatory") String mobileNumber,
			@NotEmpty(message = "address is mandatory") String address,
			@Email @NotEmpty @Pattern(regexp = "^[a-zA-Z0-9+_.-]+@[a-zA-Z]+.[a-zA-A]+", message = "enter email in valid format") String emailId,
			@NotEmpty String password, @NotEmpty String gender, String confirmPassword) {
		super();
		this.customerId = customerId;
		this.adharNumber = adharNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.address = address;
		this.emailId = emailId;
		this.password = password;
		this.gender = gender;
		this.confirmPassword = confirmPassword;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getAdharNumber() {
		return adharNumber;
	}

	public void setAdharNumber(String adharNumber) {
		this.adharNumber = adharNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
	

	

}
