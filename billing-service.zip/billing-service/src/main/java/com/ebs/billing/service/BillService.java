package com.ebs.billing.service;


import com.ebs.billing.dto.BillDto;

import java.util.List;

public interface BillService {

    public BillDto getBill(Long billId);
    public List<BillDto> getAllBills();
    public BillDto generateBill(double unitsConsumed ,Long customerId);
    public BillDto updateBill(Long billId,BillDto billDto);
    public void deleteBill(Long billId);



}
