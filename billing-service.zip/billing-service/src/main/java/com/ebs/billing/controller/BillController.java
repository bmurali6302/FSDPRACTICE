package com.ebs.billing.controller;

import com.ebs.billing.dto.BillDto;
import com.ebs.billing.service.BillService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bill")
public class BillController {

    @Autowired
    private BillService billService;

    @GetMapping("/{id}")
    public ResponseEntity<BillDto> getBill(@PathVariable Long id) {
        BillDto bill = billService.getBill(id);
        return ResponseEntity.ok(bill);
    }

    @GetMapping("/all")
    public ResponseEntity<List<BillDto>> getAllBills() {
        List<BillDto> bills = billService.getAllBills();
        return ResponseEntity.ok(bills);
    }

    @PostMapping("/generate/{unitsConsumed}/{customerId}")
    public ResponseEntity<BillDto> generateBill(@PathVariable double unitsConsumed,@PathVariable Long customerId) {
        return ResponseEntity.ok(billService.generateBill(unitsConsumed,customerId));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<BillDto> updateBill(@PathVariable Long id, @RequestBody BillDto billDto) {
        return ResponseEntity.ok(billService.updateBill(id, billDto));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteBill(@PathVariable Long id) {
        billService.deleteBill(id);
        return ResponseEntity.noContent().build();
    }
}
